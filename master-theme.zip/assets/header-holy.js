/* header-holy.js · v4
   Sticky · Mega · Mobile drawer · Cart drawer · Search drawer · Account drawer · Toast */
(function () {
  'use strict';

  var cfg = (window.HHCart && window.HHCart.config) || {};
  var MONEY_FORMAT = cfg.moneyFormat || '€{{amount}}';
  var THRESHOLD    = parseInt(cfg.threshold || 0, 10);
  var PROGRESS_T   = cfg.progressText || 'Noch [[amount]] bis zum kostenlosen Versand';
  var PROGRESS_D   = cfg.progressDone || 'Yes! Du hast den kostenlosen Versand freigeschaltet 🎉';
  var SLABELS      = (cfg.searchLabels) || { products: 'Produkte', collections: 'Kategorien', pages: 'Seiten', viewAll: 'Alle Ergebnisse für “[[q]]”' };

  // ---------- Money formatting ----------
  function formatMoney(cents) {
    var amt = (cents / 100);
    function fmt(amount, decimals, thousands, decimal) {
      decimals = isNaN(decimals) ? 2 : decimals;
      thousands = thousands || ',';
      decimal = decimal || '.';
      var fixed = parseFloat(amount).toFixed(decimals);
      var parts = fixed.split('.');
      var n = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousands);
      return n + (parts[1] ? decimal + parts[1] : '');
    }
    var out = MONEY_FORMAT;
    out = out.replace(/{{\s*amount\s*}}/g,             fmt(amt, 2, '.', ','));
    out = out.replace(/{{\s*amount_no_decimals\s*}}/g, fmt(amt, 0, '.', ','));
    out = out.replace(/{{\s*amount_with_comma_separator\s*}}/g, fmt(amt, 2, '.', ','));
    out = out.replace(/{{\s*amount_with_space_separator\s*}}/g, fmt(amt, 2, ' ', ','));
    out = out.replace(/{{\s*amount_no_decimals_with_comma_separator\s*}}/g, fmt(amt, 0, '.', ','));
    out = out.replace(/{{\s*amount_no_decimals_with_space_separator\s*}}/g, fmt(amt, 0, ' ', ','));
    return out;
  }
  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, function (c) {
      return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c];
    });
  }

  // ============================================================
  // Scrolled state + auto-hide on scroll-down, show on any up-scroll
  // ============================================================
  var trackedHeaders = document.querySelectorAll('.hh-header--sticky, .hh-header--transparent');
  if (trackedHeaders.length) {
    var lastY = window.scrollY;
    var onScroll = function () {
      var currentY = window.scrollY;
      var delta = currentY - lastY;
      var scrolled = currentY > 4;
      var atTop = currentY < 10;
      trackedHeaders.forEach(function (h) {
        h.classList.toggle('is-scrolled', scrolled);
        var autoHide = h.getAttribute('data-hh-auto-hide') === 'true';
        if (!autoHide || atTop || delta < 0) {
          h.classList.remove('is-hidden');
        } else if (delta > 3 && currentY > 120) {
          h.classList.add('is-hidden');
        }
      });
      lastY = currentY;
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  // ============================================================
  // Mega menu focus & ARIA
  // ============================================================
  document.querySelectorAll('.hh-nav__item--mega').forEach(function (item) {
    var link = item.querySelector('.hh-nav__link');
    if (!link) return;
    var openM = function () { item.classList.add('is-open'); link.setAttribute('aria-expanded','true'); };
    var closeM = function () { item.classList.remove('is-open'); link.setAttribute('aria-expanded','false'); };
    item.addEventListener('mouseenter', openM);
    item.addEventListener('mouseleave', closeM);
    link.addEventListener('focus', openM);
    item.addEventListener('focusout', function (e) { if (!item.contains(e.relatedTarget)) closeM(); });
  });

  // ============================================================
  // Scroll lock helpers (shared across drawers)
  // ============================================================
  function lockScroll()   { document.documentElement.style.overflow = 'hidden'; document.body.style.overflow = 'hidden'; }
  function unlockScroll() {
    // search popover does NOT lock scroll, so it's not in this check
    var any = document.querySelector('[data-hh-drawer][aria-hidden="false"], [data-hh-cart][aria-hidden="false"], [data-hh-account][aria-hidden="false"]');
    if (!any) {
      document.documentElement.style.overflow = '';
      document.body.style.overflow = '';
    }
  }

  // ============================================================
  // Mobile drawer
  // ============================================================
  var drawer  = document.querySelector('[data-hh-drawer]');
  var openBtn = document.querySelector('[data-hh-drawer-open]');

  function openDrawer()  { if (!drawer) return; drawer.setAttribute('aria-hidden','false'); if (openBtn) openBtn.setAttribute('aria-expanded','true');  lockScroll(); }
  function closeDrawer() { if (!drawer) return; drawer.setAttribute('aria-hidden','true');  if (openBtn) openBtn.setAttribute('aria-expanded','false'); unlockScroll(); }

  if (openBtn) openBtn.addEventListener('click', openDrawer);
  document.querySelectorAll('[data-hh-drawer-close]').forEach(function (el) { el.addEventListener('click', closeDrawer); });
  document.querySelectorAll('.hh-drawer__toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      btn.setAttribute('aria-expanded', btn.getAttribute('aria-expanded') === 'true' ? 'false' : 'true');
    });
  });

  // Language picker: custom dropdown open/close.
  // Supports multiple instances (header + drawer) — each [data-hh-lang] is independent.
  var langInstances = [];
  document.querySelectorAll('[data-hh-lang]').forEach(function (container) {
    var uid = container.getAttribute('data-hh-lang');
    var trigger = container.querySelector('[data-hh-lang-trigger="' + uid + '"]');
    var popup   = container.querySelector('[data-hh-lang-popup="' + uid + '"]');
    if (!trigger || !popup) return;

    var setOpen = function (open) {
      if (open) {
        // close every OTHER lang dropdown before opening this one
        langInstances.forEach(function (inst) { if (inst.popup !== popup) inst.setOpen(false); });
        popup.removeAttribute('hidden');
        trigger.setAttribute('aria-expanded', 'true');
      } else {
        popup.setAttribute('hidden', '');
        trigger.setAttribute('aria-expanded', 'false');
      }
    };

    trigger.addEventListener('click', function (e) {
      e.stopPropagation();
      e.preventDefault();
      setOpen(popup.hasAttribute('hidden'));
    });

    langInstances.push({ trigger: trigger, popup: popup, setOpen: setOpen });
  });

  document.addEventListener('click', function (e) {
    langInstances.forEach(function (inst) {
      if (inst.popup.hasAttribute('hidden')) return;
      if (!inst.popup.contains(e.target) && !inst.trigger.contains(e.target)) inst.setOpen(false);
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    langInstances.forEach(function (inst) {
      if (!inst.popup.hasAttribute('hidden')) inst.setOpen(false);
    });
  });

  // ============================================================
  // Cart drawer
  // ============================================================
  var cartEl    = document.querySelector('[data-hh-cart]');
  var cartLoad  = document.querySelector('[data-hh-cart-loading]');
  var cartEmpty = document.querySelector('[data-hh-cart-empty]');
  var cartItems = document.querySelector('[data-hh-cart-items]');
  var cartFoot  = document.querySelector('[data-hh-cart-foot]');
  var cartSubt  = document.querySelector('[data-hh-cart-subtotal]');
  var cartTitleCount = document.querySelector('[data-hh-cart-title-count]');
  var cartProgress     = document.querySelector('[data-hh-cart-progress]');
  var cartProgressText = document.querySelector('[data-hh-cart-progress-text]');
  var cartProgressFill = document.querySelector('[data-hh-cart-progress-fill]');
  var cartCountEl = document.querySelector('[data-hh-cart-count]');
  var lastCount = cartCountEl ? (parseInt(cartCountEl.textContent, 10) || 0) : 0;

  function openCart()  { if (!cartEl) return; cartEl.setAttribute('aria-hidden','false'); lockScroll(); fetchAndRender(); }
  function closeCart() { if (!cartEl) return; cartEl.setAttribute('aria-hidden','true');  unlockScroll(); }

  document.querySelectorAll('[data-hh-cart-trigger]').forEach(function (el) {
    el.addEventListener('click', function (e) { e.preventDefault(); openCart(); });
  });
  document.querySelectorAll('[data-hh-cart-close]').forEach(function (el) { el.addEventListener('click', closeCart); });

  function setVisible(el, on) { if (!el) return; if (on) el.removeAttribute('hidden'); else el.setAttribute('hidden',''); }

  function renderCart(cart) {
    if (!cartItems) return;
    if (cartTitleCount) cartTitleCount.textContent = '(' + cart.item_count + ')';
    updateCartCountBadge(cart.item_count);
    setVisible(cartLoad, false);

    if (!cart.items || cart.items.length === 0) {
      setVisible(cartEmpty, true); setVisible(cartItems, false); setVisible(cartFoot, false);
      return;
    }
    setVisible(cartEmpty, false); setVisible(cartItems, true); setVisible(cartFoot, true);

    var html = cart.items.map(function (item, idx) {
      var img = item.image ? item.image.replace(/(\.[a-z]+)(\?|$)/i, '_120x$1$2') : '';
      var price = item.original_line_price !== item.final_line_price
        ? '<s>' + formatMoney(item.original_line_price) + '</s>' + formatMoney(item.final_line_price)
        : formatMoney(item.final_line_price);
      var variant = item.variant_options && item.variant_options.length
        ? item.variant_options.filter(function (v) { return v && v !== 'Default Title'; }).join(' · ')
        : (item.variant_title && item.variant_title !== 'Default Title' ? item.variant_title : '');
      return '' +
        '<li class="hh-cart__item" data-line="' + (idx + 1) + '" data-key="' + escapeHtml(item.key) + '">' +
          '<a href="' + escapeHtml(item.url) + '" class="hh-cart__item-img-wrap" tabindex="-1">' +
            (img ? '<img class="hh-cart__item-img" src="' + escapeHtml(img) + '" alt="' + escapeHtml(item.product_title) + '" loading="lazy">' : '') +
          '</a>' +
          '<div class="hh-cart__item-body">' +
            '<a class="hh-cart__item-title" href="' + escapeHtml(item.url) + '">' + escapeHtml(item.product_title) + '</a>' +
            (variant ? '<span class="hh-cart__item-variant">' + escapeHtml(variant) + '</span>' : '') +
            '<span class="hh-cart__item-price">' + price + '</span>' +
          '</div>' +
          '<div class="hh-cart__item-right">' +
            '<button type="button" class="hh-cart__item-remove" aria-label="Entfernen" data-hh-remove="' + (idx + 1) + '">' +
              '<svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>' +
            '</button>' +
            '<div class="hh-cart__qty">' +
              '<button type="button" class="hh-cart__qty-btn" data-hh-qty="' + (idx + 1) + '" data-delta="-1" aria-label="Menge verringern">' +
                '<svg viewBox="0 0 12 12" width="12" height="12"><path d="M2 6h8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>' +
              '</button>' +
              '<input class="hh-cart__qty-input" type="number" min="0" value="' + item.quantity + '" data-hh-qty-input="' + (idx + 1) + '">' +
              '<button type="button" class="hh-cart__qty-btn" data-hh-qty="' + (idx + 1) + '" data-delta="1" aria-label="Menge erhöhen">' +
                '<svg viewBox="0 0 12 12" width="12" height="12"><path d="M6 2v8M2 6h8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>' +
              '</button>' +
            '</div>' +
          '</div>' +
        '</li>';
    }).join('');

    cartItems.innerHTML = html;
    if (cartSubt) cartSubt.textContent = formatMoney(cart.items_subtotal_price || cart.total_price);

    if (cartProgress && THRESHOLD > 0) {
      var subtotal = cart.items_subtotal_price || cart.total_price || 0;
      var pct = Math.min(100, (subtotal / THRESHOLD) * 100);
      cartProgressFill.style.width = pct + '%';
      if (subtotal >= THRESHOLD) { cartProgress.classList.add('is-complete'); cartProgressText.textContent = PROGRESS_D; }
      else { cartProgress.classList.remove('is-complete'); cartProgressText.textContent = PROGRESS_T.replace('[[amount]]', formatMoney(THRESHOLD - subtotal)); }
    }

    bindCartRowHandlers();
  }

  function bindCartRowHandlers() {
    cartItems.querySelectorAll('[data-hh-qty]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var line = parseInt(btn.getAttribute('data-hh-qty'), 10);
        var delta = parseInt(btn.getAttribute('data-delta'), 10);
        var input = cartItems.querySelector('[data-hh-qty-input="' + line + '"]');
        changeLine(line, Math.max(0, (parseInt(input.value, 10) || 0) + delta));
      });
    });
    cartItems.querySelectorAll('[data-hh-qty-input]').forEach(function (input) {
      input.addEventListener('change', function () {
        var line = parseInt(input.getAttribute('data-hh-qty-input'), 10);
        changeLine(line, Math.max(0, parseInt(input.value, 10) || 0));
      });
    });
    cartItems.querySelectorAll('[data-hh-remove]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var line = parseInt(btn.getAttribute('data-hh-remove'), 10);
        var row = btn.closest('.hh-cart__item');
        if (row) row.classList.add('is-removing');
        setTimeout(function () { changeLine(line, 0); }, 280);
      });
    });
  }

  function changeLine(line, quantity) {
    return fetch('/cart/change.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ line: line, quantity: quantity })
    })
      .then(function (r) { return r.json(); })
      .then(function (cart) { renderCart(cart); document.dispatchEvent(new CustomEvent('cart:updated', { detail: cart })); })
      .catch(function () { fetchAndRender(); });
  }

  function fetchAndRender() {
    if (!cartItems) return;
    setVisible(cartLoad, true); setVisible(cartEmpty, false); setVisible(cartItems, false); setVisible(cartFoot, false);
    fetch('/cart.js', { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(renderCart)
      .catch(function () { setVisible(cartLoad, false); });
  }

  function updateCartCountBadge(n) {
    if (!cartCountEl) return;
    var num = parseInt(n, 10) || 0;
    var changed = num !== lastCount;
    cartCountEl.textContent = num;
    cartCountEl.setAttribute('data-empty', String(num === 0));
    if (changed && num > lastCount) {
      cartCountEl.classList.remove('hh-cart-count--pop');
      void cartCountEl.offsetWidth;
      cartCountEl.classList.add('hh-cart-count--pop');
    }
    lastCount = num;
  }

  function silentRefreshCart() {
    return fetch('/cart.js', { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (cart) {
        if (!cart) return null;
        updateCartCountBadge(cart.item_count);
        if (cartEl && cartEl.getAttribute('aria-hidden') === 'false') renderCart(cart);
        return cart;
      })
      .catch(function () { return null; });
  }

  // ============================================================
  // Search popover (compact floating panel + recents)
  // ============================================================
  var searchEl       = document.querySelector('[data-hh-search]');
  var searchInput    = document.querySelector('[data-hh-search-input]');
  var searchX        = document.querySelector('[data-hh-search-x]');
  var searchSpinner  = document.querySelector('[data-hh-search-spinner]');
  var searchIntro    = document.querySelector('[data-hh-search-intro]');
  var searchResults  = document.querySelector('[data-hh-search-results]');
  var searchEmpty    = document.querySelector('[data-hh-search-empty]');
  var searchForm     = document.querySelector('[data-hh-search-form]');
  var searchBody     = document.querySelector('[data-hh-search-body]');
  var searchRecent      = document.querySelector('[data-hh-search-recent]');
  var searchRecentList  = document.querySelector('[data-hh-search-recent-list]');
  var searchRecentClear = document.querySelector('[data-hh-search-recent-clear]');

  // --- Position the popover under the bar (no scroll-lock; page stays scrollable) ---
  function positionSearch() {
    if (!searchEl) return;
    var pop = searchEl.querySelector('.hh-panel__panel');
    if (!pop) return;
    var bar = document.querySelector('.hh-bar');
    var top = 96;
    if (bar) {
      var rect = bar.getBoundingClientRect();
      top = Math.max(8, Math.round(rect.bottom + 8));
    }
    var maxH = Math.max(240, window.innerHeight - top - 16);
    pop.style.setProperty('--hh-search-top', top + 'px');
    pop.style.setProperty('--hh-search-maxh', maxH + 'px');
  }

  function openSearch() {
    if (!searchEl) return;
    positionSearch();
    renderRecent();
    searchEl.setAttribute('aria-hidden', 'false');
    setTimeout(function () { if (searchInput) searchInput.focus(); }, 200);
  }
  function closeSearch() {
    if (!searchEl) return;
    searchEl.setAttribute('aria-hidden', 'true');
  }

  document.querySelectorAll('[data-hh-search-trigger]').forEach(function (el) {
    el.addEventListener('click', function (e) { e.preventDefault(); openSearch(); });
  });
  document.querySelectorAll('[data-hh-search-close]').forEach(function (el) {
    el.addEventListener('click', closeSearch);
  });
  window.addEventListener('scroll', function () {
    if (searchEl && searchEl.getAttribute('aria-hidden') === 'false') positionSearch();
  }, { passive: true });
  window.addEventListener('resize', positionSearch);

  // Dual-mode X: clear when typed, close popover when empty
  function updateXMode() {
    if (!searchX || !searchInput) return;
    if (searchInput.value !== '') {
      searchX.setAttribute('data-mode', 'clear');
      searchX.setAttribute('aria-label', 'Eingabe löschen');
    } else {
      searchX.setAttribute('data-mode', 'close');
      searchX.setAttribute('aria-label', 'Schließen');
    }
  }
  if (searchX && searchInput) {
    searchX.addEventListener('click', function () {
      if (searchInput.value !== '') {
        searchInput.value = '';
        updateXMode();
        runSearch('');
        searchInput.focus();
      } else {
        closeSearch();
      }
    });
  }
  updateXMode();

  // Popular pills + recent text buttons (delegated)
  document.addEventListener('click', function (e) {
    var pill = e.target.closest('[data-hh-search-term]');
    if (!pill || !searchInput) return;
    var term = pill.getAttribute('data-hh-search-term');
    searchInput.value = term;
    updateXMode();
    runSearch(term);
    searchInput.focus();
  });

  // Submit pushes to recents, then native navigation to /search
  if (searchForm) {
    searchForm.addEventListener('submit', function () {
      if (searchInput && searchInput.value.trim()) pushRecent(searchInput.value.trim());
    });
  }

  // Clicking a real result link pushes the query to recents
  if (searchBody) {
    searchBody.addEventListener('click', function (e) {
      var link = e.target.closest('a.hh-search__item, a.hh-search__viewall');
      if (link && searchInput && searchInput.value.trim()) {
        pushRecent(searchInput.value.trim());
      }
    });
  }

  // --- localStorage recents ---
  var RECENT_KEY = 'hh-recent-searches';
  var MAX_RECENT = 8;

  function getRecent() {
    try { var v = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]'); return Array.isArray(v) ? v : []; }
    catch (e) { return []; }
  }
  function saveRecent(list) {
    try { localStorage.setItem(RECENT_KEY, JSON.stringify(list)); } catch (e) {}
  }
  function pushRecent(q) {
    q = (q || '').trim();
    if (!q) return;
    var list = getRecent().filter(function (x) { return x.toLowerCase() !== q.toLowerCase(); });
    list.unshift(q);
    list = list.slice(0, MAX_RECENT);
    saveRecent(list);
    renderRecent();
  }
  function removeRecent(q) {
    var list = getRecent().filter(function (x) { return x !== q; });
    saveRecent(list);
    renderRecent();
  }
  function clearAllRecent() {
    saveRecent([]);
    renderRecent();
  }
  function renderRecent() {
    if (!searchRecent || !searchRecentList) return;
    var list = getRecent();
    if (!list.length) { setVisible(searchRecent, false); return; }
    setVisible(searchRecent, true);
    searchRecentList.innerHTML = list.map(function (q) {
      var safe = escapeHtml(q);
      return '' +
        '<li class="hh-search__recent-item">' +
          '<span class="hh-search__recent-icon" aria-hidden="true">' +
            '<svg viewBox="0 0 16 16" width="12" height="12">' +
              '<circle cx="8" cy="8" r="6" fill="none" stroke="currentColor" stroke-width="1.5"/>' +
              '<path d="M8 5v3l2 1.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
            '</svg>' +
          '</span>' +
          '<button type="button" class="hh-search__recent-text" data-hh-search-term="' + safe + '">' + safe + '</button>' +
          '<svg class="hh-search__recent-arrow" width="12" height="12" viewBox="0 0 12 12" aria-hidden="true">' +
            '<path d="M3 6h6m0 0L6 3m3 3L6 9" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>' +
          '</svg>' +
          '<button type="button" class="hh-search__recent-remove" data-hh-recent-remove="' + safe + '" aria-label="Entfernen">' +
            '<svg viewBox="0 0 12 12" width="11" height="11" aria-hidden="true"><path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>' +
          '</button>' +
        '</li>';
    }).join('');
    // Remove handlers
    searchRecentList.querySelectorAll('[data-hh-recent-remove]').forEach(function (rm) {
      rm.addEventListener('click', function (e) {
        e.stopPropagation();
        e.preventDefault();
        removeRecent(rm.getAttribute('data-hh-recent-remove'));
      });
    });
  }

  if (searchRecentClear) {
    searchRecentClear.addEventListener('click', clearAllRecent);
  }
  // Initial render so the section appears even before opening the popover
  renderRecent();

  var searchTimer = null;
  var searchCtrl  = null;

  if (searchInput) {
    searchInput.addEventListener('input', function () {
      var v = searchInput.value;
      updateXMode();
      clearTimeout(searchTimer);
      searchTimer = setTimeout(function () { runSearch(v); }, 220);
    });
  }

  function runSearch(q) {
    var query = (q || '').trim();
    if (searchSpinner) {
      if (query) setVisible(searchSpinner, true); else setVisible(searchSpinner, false);
    }

    if (!query) {
      // Show recents + popular (and hide results / empty state)
      renderRecent();
      setVisible(searchIntro,   true);
      setVisible(searchResults, false);
      setVisible(searchEmpty,   false);
      setVisible(searchSpinner, false);
      if (searchResults) searchResults.innerHTML = '';
      return;
    }
    // Typing → hide recents & popular
    setVisible(searchRecent, false);
    setVisible(searchIntro,  false);

    if (searchCtrl) try { searchCtrl.abort(); } catch (e) {}
    searchCtrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;

    var url = '/search/suggest.json?q=' + encodeURIComponent(query) +
              '&resources[type]=product,collection,page' +
              '&resources[limit]=6&resources[options][unavailable_products]=last';

    fetch(url, {
      headers: { 'Accept': 'application/json' },
      credentials: 'same-origin',
      signal: searchCtrl ? searchCtrl.signal : undefined
    })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        setVisible(searchSpinner, false);
        if (!data || !data.resources || !data.resources.results) {
          renderSearchEmpty(query); return;
        }
        renderSearchResults(query, data.resources.results);
      })
      .catch(function (err) {
        if (err && err.name === 'AbortError') return;
        setVisible(searchSpinner, false);
        renderSearchEmpty(query);
      });
  }

  function renderSearchEmpty(query) {
    setVisible(searchRecent,  false);
    setVisible(searchIntro,   false);
    setVisible(searchResults, false);
    setVisible(searchEmpty,   true);
  }

  function renderSearchResults(query, results) {
    var products    = results.products    || [];
    var collections = results.collections || [];
    var pages       = results.pages       || [];

    if (!products.length && !collections.length && !pages.length) {
      renderSearchEmpty(query); return;
    }

    setVisible(searchRecent,  false);
    setVisible(searchIntro,   false);
    setVisible(searchEmpty,   false);
    setVisible(searchResults, true);

    var html = '';

    if (products.length) {
      html += '<div class="hh-search__group">';
      html +=   '<div class="hh-search__group-label">' + escapeHtml(SLABELS.products) + '</div>';
      html +=   '<ul class="hh-search__items">';
      products.forEach(function (p) {
        var img = p.featured_image && p.featured_image.url ? p.featured_image.url : p.image;
        if (img) img = String(img).replace(/(\.[a-z]+)(\?|$)/i, '_120x$1$2');
        var compare = p.price_min !== undefined ? p.price_min : (p.price || 0);
        var priceMin  = parseFloat(p.price_min  || p.price || 0) * 100;
        var priceMax  = parseFloat(p.price_max  || p.price || 0) * 100;
        var compareAt = parseFloat(p.compare_at_price_min || 0) * 100;
        var priceHtml = (compareAt && compareAt > priceMin)
          ? '<s>' + formatMoney(compareAt) + '</s>' + formatMoney(priceMin)
          : (priceMax > priceMin ? 'ab ' + formatMoney(priceMin) : formatMoney(priceMin));
        html += '<li><a class="hh-search__item" href="' + escapeHtml(p.url) + '">' +
                  '<div class="hh-search__item-img-wrap">' +
                    (img ? '<img class="hh-search__item-img" src="' + escapeHtml(img) + '" alt="" loading="lazy">' : '') +
                  '</div>' +
                  '<div class="hh-search__item-body">' +
                    '<span class="hh-search__item-title">' + escapeHtml(p.title) + '</span>' +
                    '<span class="hh-search__item-meta">' + priceHtml + '</span>' +
                  '</div>' +
                  '<svg class="hh-search__item-arrow" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M4 2l5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
                '</a></li>';
      });
      html +=   '</ul>';
      html += '</div>';
    }

    if (collections.length) {
      html += '<div class="hh-search__group">';
      html +=   '<div class="hh-search__group-label">' + escapeHtml(SLABELS.collections) + '</div>';
      html +=   '<ul class="hh-search__items">';
      collections.forEach(function (c) {
        html += '<li><a class="hh-search__item" href="' + escapeHtml(c.url) + '">' +
                  '<div class="hh-search__item-img-wrap" style="display:flex;align-items:center;justify-content:center;">' +
                    '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" style="opacity:.45"><path d="M3 7h18v13H3zM3 7l3-4h12l3 4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>' +
                  '</div>' +
                  '<div class="hh-search__item-body">' +
                    '<span class="hh-search__item-title">' + escapeHtml(c.title) + '</span>' +
                    '<span class="hh-search__item-meta">' + escapeHtml(SLABELS.collections) + '</span>' +
                  '</div>' +
                  '<svg class="hh-search__item-arrow" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M4 2l5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
                '</a></li>';
      });
      html +=   '</ul>';
      html += '</div>';
    }

    if (pages.length) {
      html += '<div class="hh-search__group">';
      html +=   '<div class="hh-search__group-label">' + escapeHtml(SLABELS.pages) + '</div>';
      html +=   '<ul class="hh-search__items">';
      pages.forEach(function (pg) {
        html += '<li><a class="hh-search__item" href="' + escapeHtml(pg.url) + '">' +
                  '<div class="hh-search__item-img-wrap" style="display:flex;align-items:center;justify-content:center;">' +
                    '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" style="opacity:.45"><path d="M6 3h9l4 4v14H6z" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M15 3v4h4" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>' +
                  '</div>' +
                  '<div class="hh-search__item-body">' +
                    '<span class="hh-search__item-title">' + escapeHtml(pg.title) + '</span>' +
                    '<span class="hh-search__item-meta">' + escapeHtml(SLABELS.pages) + '</span>' +
                  '</div>' +
                  '<svg class="hh-search__item-arrow" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M4 2l5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
                '</a></li>';
      });
      html +=   '</ul>';
      html += '</div>';
    }

    html += '<a class="hh-search__viewall" href="/search?q=' + encodeURIComponent(query) + '">' +
            escapeHtml(SLABELS.viewAll.replace('[[q]]', query)) +
            '<svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M2 7h9m0 0L7 3m4 4-4 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            '</a>';

    if (searchResults) searchResults.innerHTML = html;
  }

  // ============================================================
  // Account drawer
  // ============================================================
  var accountEl = document.querySelector('[data-hh-account]');
  function openAccount()  { if (!accountEl) return; accountEl.setAttribute('aria-hidden','false'); lockScroll(); }
  function closeAccount() { if (!accountEl) return; accountEl.setAttribute('aria-hidden','true');  unlockScroll(); }

  document.querySelectorAll('[data-hh-account-trigger]').forEach(function (el) {
    el.addEventListener('click', function (e) { e.preventDefault(); openAccount(); });
  });
  document.querySelectorAll('[data-hh-account-close]').forEach(function (el) {
    el.addEventListener('click', closeAccount);
  });

  // ============================================================
  // Global ESC — closes the topmost open overlay
  // ============================================================
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (searchEl  && searchEl.getAttribute('aria-hidden')  === 'false') return closeSearch();
    if (accountEl && accountEl.getAttribute('aria-hidden') === 'false') return closeAccount();
    if (cartEl    && cartEl.getAttribute('aria-hidden')    === 'false') return closeCart();
    if (drawer    && drawer.getAttribute('aria-hidden')    === 'false') return closeDrawer();
    hideToast();
  });

  // ============================================================
  // Toast
  // ============================================================
  var toastEl    = document.querySelector('[data-hh-toast]');
  var toastDesc  = document.querySelector('[data-hh-toast-desc]');
  var toastMedia = document.querySelector('[data-hh-toast-media]');
  var toastCart  = document.querySelector('[data-hh-toast-cart]');
  var toastTimer = null;

  function showToast(info) {
    if (!toastEl) return;
    if (toastDesc)  toastDesc.textContent = info.title || '';
    if (toastMedia) {
      if (info.image) { toastMedia.innerHTML = '<img src="' + escapeHtml(info.image) + '" alt="">'; toastMedia.classList.add('is-shown'); }
      else { toastMedia.innerHTML = ''; toastMedia.classList.remove('is-shown'); }
    }
    toastEl.setAttribute('aria-hidden','false');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(hideToast, 3500);
  }
  function hideToast() { if (toastEl) toastEl.setAttribute('aria-hidden','true'); clearTimeout(toastTimer); }
  if (toastCart) toastCart.addEventListener('click', function () { hideToast(); openCart(); });

  // ============================================================
  // Intercept cart-mutating XHR/fetch
  // ============================================================
  function handleAddResponse(item) {
    if (!item) { silentRefreshCart(); return; }
    var img = item.image || item.featured_image || item.featured_image_url || '';
    if (img && img.indexOf('//') === 0) img = 'https:' + img;
    if (img) img = String(img).replace(/(\.[a-z]+)(\?|$)/i, '_80x$1$2');
    var info = { title: item.product_title || item.title || '', image: img };
    silentRefreshCart().then(function () { showToast(info); });
  }

  if (window.fetch) {
    var origFetch = window.fetch;
    window.fetch = function (input, init) {
      var url = typeof input === 'string' ? input : (input && input.url) || '';
      var p = origFetch.apply(this, arguments);
      if (/\/cart\/add(\.js|\.json|$|\?)/.test(url)) {
        p.then(function (r) {
          if (!r || !r.ok) return null;
          return r.clone().json().catch(function () { return null; });
        }).then(handleAddResponse).catch(function () { silentRefreshCart(); });
      } else if (/\/cart\/(change|update|clear)/.test(url)) {
        p.then(function () { setTimeout(silentRefreshCart, 60); }).catch(function () {});
      }
      return p;
    };
  }

  if (window.XMLHttpRequest) {
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url) {
      this.__hhUrl = url || '';
      return origOpen.apply(this, arguments);
    };
    var origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
      var self = this;
      this.addEventListener('load', function () {
        var url = self.__hhUrl || '';
        if (/\/cart\/add(\.js|\.json|$|\?)/.test(url)) {
          var item = null; try { item = JSON.parse(self.responseText); } catch (e) {}
          handleAddResponse(item);
        } else if (/\/cart\/(change|update|clear)/.test(url)) {
          setTimeout(silentRefreshCart, 60);
        }
      });
      return origSend.apply(this, arguments);
    };
  }

  document.addEventListener('cart:updated', silentRefreshCart);
})();
